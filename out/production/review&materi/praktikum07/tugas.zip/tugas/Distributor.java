package praktikum07.tugas;

public interface Distributor {
    public String pembeliDari();
    public String pembeli();
    public String jenisBarang();
    public int jumlahBarang();
    public String alamat();
}
